package com.example.jpaRestExam.product.service;

import com.example.jpaRestExam.product.model.Category;
import com.example.jpaRestExam.product.model.ProductRequest;

import java.util.List;

public interface ProductService {
    List<Category> getCategory();
    void insert(ProductRequest request) ;
}
