package com.example.jpaRestExam.product.controller;

import com.example.jpaRestExam.product.model.Category;
import com.example.jpaRestExam.product.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Controller
@RequestMapping("/product")
@RequiredArgsConstructor
public class ProductRestController {

    private final ProductService service;

    @GetMapping("insert")
    public String insertPage(Model model) {
        List<Category> category = service.getCategory();
        model.addAttribute("categorylist",category);
        return "product/prdinsert";
    }

}
