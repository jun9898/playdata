package com.example.jpaRestExam.product.service;

import com.example.jpaRestExam.product.dao.ProductDAO;
import com.example.jpaRestExam.product.model.Category;
import com.example.jpaRestExam.product.model.ProductRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
@RequiredArgsConstructor
@Service
public class ProductServiceImpl implements ProductService{
    private final ProductDAO dao;
    @Override
    public List<Category> getCategory() {
        return dao.getCategory();
    }

    @Override
    public void insert(ProductRequest request) {
      
    }


}
