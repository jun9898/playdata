package com.example.jpaRestExam.product.model;

public class ProductRequest {
}
