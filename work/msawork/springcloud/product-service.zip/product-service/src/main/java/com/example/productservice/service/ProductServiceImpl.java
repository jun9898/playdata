package com.example.productservice.service;

import com.example.productservice.dao.ProductDAO;
import com.example.productservice.dto.ProductRequest;
import com.example.productservice.dto.ProductResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService{
    private final ProductDAO dao;
    @Override
    public void write(ProductRequest product) {

    }

    @Override
    public ProductResponse findByProductNo(Long productNo) {
        return null;
    }

    @Override
    public List<ProductResponse> findAll() {
        return null;
    }
}
